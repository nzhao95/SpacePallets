#ifndef ALL_H
#define ALL_H

#include "2023/REC991.h"
#include "2023/draw.h"
#include "physicshelper.h"

#endif
